"""
AWS Lambda Function - Presigned URL Generator
==============================================
Gera URLs pré-assinadas para upload e download de arquivos no S3.
"""

import os
import json
import boto3
from botocore.config import Config

# Configuração do cliente S3 com assinatura v4
s3_client = boto3.client(
    's3',
    region_name='us-east-1',
    config=Config(signature_version='s3v4')
)

# Buckets
INPUT_BUCKET = os.environ.get('INPUT_BUCKET', 'thumbnail-app-input-davicoelho')
OUTPUT_BUCKET = os.environ.get('OUTPUT_BUCKET', 'thumbnail-app-output-davicoelho')

# Tempo de expiração das URLs (em segundos)
UPLOAD_EXPIRATION = 300  # 5 minutos
DOWNLOAD_EXPIRATION = 3600  # 1 hora


def lambda_handler(event, context):
    """
    Handler principal.
    
    Endpoints:
    - POST /upload-url: Gera URL para upload
    - POST /download-url: Gera URL para download
    - GET /status/{key}: Verifica se a thumbnail foi gerada
    """
    
    # Headers CORS
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Content-Type': 'application/json'
    }
    
    # Tratar preflight CORS
    http_method = event.get('httpMethod', event.get('requestContext', {}).get('http', {}).get('method', ''))
    if http_method == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': ''
        }
    
    try:
        # Extrair path e body
        path = event.get('path', event.get('rawPath', ''))
        body = {}
        if event.get('body'):
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        
        # Roteamento
        if '/upload-url' in path:
            return generate_upload_url(body, headers)
        elif '/download-url' in path:
            return generate_download_url(body, headers)
        elif '/status' in path:
            return check_thumbnail_status(event, headers)
        else:
            return {
                'statusCode': 404,
                'headers': headers,
                'body': json.dumps({'error': 'Endpoint não encontrado'})
            }
            
    except Exception as e:
        print(f"Erro: {str(e)}")
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'error': str(e)})
        }


def generate_upload_url(body, headers):
    """Gera URL pré-assinada para upload."""
    
    filename = body.get('filename')
    content_type = body.get('contentType', 'image/jpeg')
    
    if not filename:
        return {
            'statusCode': 400,
            'headers': headers,
            'body': json.dumps({'error': 'filename é obrigatório'})
        }
    
    # Gerar URL pré-assinada para PUT
    presigned_url = s3_client.generate_presigned_url(
        'put_object',
        Params={
            'Bucket': INPUT_BUCKET,
            'Key': filename,
            'ContentType': content_type
        },
        ExpiresIn=UPLOAD_EXPIRATION
    )
    
    return {
        'statusCode': 200,
        'headers': headers,
        'body': json.dumps({
            'uploadUrl': presigned_url,
            'key': filename,
            'bucket': INPUT_BUCKET,
            'expiresIn': UPLOAD_EXPIRATION
        })
    }


def generate_download_url(body, headers):
    """Gera URL pré-assinada para download."""
    
    key = body.get('key')
    
    if not key:
        return {
            'statusCode': 400,
            'headers': headers,
            'body': json.dumps({'error': 'key é obrigatório'})
        }
    
    # Construir chave da thumbnail
    thumbnail_key = f"thumbnails/{key.rsplit('.', 1)[0]}_thumbnail.jpg"
    
    # Verificar se o arquivo existe
    try:
        s3_client.head_object(Bucket=OUTPUT_BUCKET, Key=thumbnail_key)
    except:
        return {
            'statusCode': 404,
            'headers': headers,
            'body': json.dumps({'error': 'Thumbnail ainda não foi gerada', 'key': thumbnail_key})
        }
    
    # Gerar URL pré-assinada para GET
    presigned_url = s3_client.generate_presigned_url(
        'get_object',
        Params={
            'Bucket': OUTPUT_BUCKET,
            'Key': thumbnail_key
        },
        ExpiresIn=DOWNLOAD_EXPIRATION
    )
    
    return {
        'statusCode': 200,
        'headers': headers,
        'body': json.dumps({
            'downloadUrl': presigned_url,
            'key': thumbnail_key,
            'bucket': OUTPUT_BUCKET,
            'expiresIn': DOWNLOAD_EXPIRATION
        })
    }


def check_thumbnail_status(event, headers):
    """Verifica se a thumbnail foi gerada."""
    
    # Extrair key do path ou query
    path_params = event.get('pathParameters', {}) or {}
    query_params = event.get('queryStringParameters', {}) or {}
    
    key = path_params.get('key') or query_params.get('key')
    
    if not key:
        return {
            'statusCode': 400,
            'headers': headers,
            'body': json.dumps({'error': 'key é obrigatório'})
        }
    
    # Construir chave da thumbnail
    thumbnail_key = f"thumbnails/{key.rsplit('.', 1)[0]}_thumbnail.jpg"
    
    # Verificar se o arquivo existe
    try:
        response = s3_client.head_object(Bucket=OUTPUT_BUCKET, Key=thumbnail_key)
        
        # Gerar URL para download
        download_url = s3_client.generate_presigned_url(
            'get_object',
            Params={
                'Bucket': OUTPUT_BUCKET,
                'Key': thumbnail_key
            },
            ExpiresIn=DOWNLOAD_EXPIRATION
        )
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'status': 'ready',
                'key': thumbnail_key,
                'size': response['ContentLength'],
                'downloadUrl': download_url
            })
        }
    except s3_client.exceptions.ClientError as e:
        if e.response['Error']['Code'] == '404':
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({
                    'status': 'processing',
                    'key': thumbnail_key
                })
            }
        raise
